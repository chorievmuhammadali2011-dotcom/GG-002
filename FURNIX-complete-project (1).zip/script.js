const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const translations = {
  ru: {
    announcement:"Бесплатная доставка от 5 000 000 сум · 14 дней на возврат",navCatalog:"Каталог",navCollections:"Коллекции",navAbout:"О бренде",navContacts:"Контакты",searchPlaceholder:"Поиск мебели...",
    heroEyebrow:"ИСКУССТВО ЖИТЬ КРАСИВО",heroTitleA:"Пространство,",heroTitleB:"в котором",heroTitleC:"хочется жить.",heroText:"Продуманная мебель, натуральные фактуры и детали, которые превращают дом в особенное место.",heroButton:"Смотреть коллекцию ↗",learnMore:"Узнать о FURNIX",heroNote:"Дизайн с характером. Комфорт на каждый день.",trustOne:"Продуманный дизайн",trustTwo:"Качество материалов",trustThree:"Доставка по Узбекистану",trustFour:"Забота после покупки",
    categoryEyebrow:"НАЙДИТЕ СВОЙ СТИЛЬ",categoryTitle:"Комнаты с характером",allCategories:"Все категории ↗",catBeds:"Кровати и спальни",catSofas:"Диваны и уголки",catStorage:"Шкафы и комоды",catTables:"Столы и стулья",catalogEyebrow:"ИЗБРАННОЕ FURNIX",catalogTitle:"Предметы для жизни",filterAll:"Все",filterBeds:"Кровати",filterSofas:"Диваны",filterStorage:"Шкафы",filterTables:"Столы",filterOther:"Другое",sortFeatured:"Сначала популярные",sortLow:"Сначала дешевле",sortHigh:"Сначала дороже",emptyProducts:"Ничего не найдено.",addToCart:"Добавить в корзину",categoryBeds:"Спальня",categorySofas:"Гостиная",categoryStorage:"Хранение",categoryTables:"Столовая",categoryOther:"Другое",added:"Добавлено в корзину",favoriteAdded:"Добавлено в избранное",favoriteRemoved:"Удалено из избранного",
    editorialEyebrow:"МЕНЬШЕ, НО ЛУЧШЕ",editorialTitle:"Красота —<br><em>в простоте.</em>",editorialText:"Мы верим, что мебель должна не просто заполнять пространство, а помогать чувствовать себя дома.",editorialLink:"Открыть каталог ↗",benefitsEyebrow:"ПОЧЕМУ FURNIX",benefitsTitle:"Покупка без лишних забот",benefitOneTitle:"Подбор с заботой",benefitOneText:"Поможем выбрать мебель под ваш интерьер.",benefitTwoTitle:"Доставка и сборка",benefitTwoText:"Согласуем удобное время доставки.",benefitThreeTitle:"Надёжные материалы",benefitThreeText:"Внимание к качеству исполнения.",benefitFourTitle:"Поддержка рядом",benefitFourText:"Остаёмся на связи после покупки.",
    newsletterEyebrow:"FURNIX JOURNAL",newsletterTitle:"Вдохновение для вашего дома.",newsletterText:"Оставьте номер — мы свяжемся с вами.",subscribe:"Оставить заявку ↗",privacyNote:"Демо-форма: заявка сохранится только в этом браузере.",footerText:"Создаём пространство, в котором хочется быть.",footerExplore:"Исследуйте",footerContact:"Связаться",footerVisit:"Мы на карте",addressText:"Ташкент, Узбекистан",openMap:"Открыть карту ↗",adminEntry:"Вход для администратора",rights:"Все права защищены.",footerMade:"Дизайн пространства начинается здесь.",
    cartTitle:"Ваша корзина",total:"Итого",checkout:"Оформить заказ ↗",checkoutDemo:"Демонстрационный режим: оплата и отправка не подключены.",emptyCart:"В корзине пока пусто.",checkoutTitle:"Оформление заказа",yourName:"Ваше имя",phone:"Номер телефона",deliveryAddress:"Адрес доставки",orderComment:"Комментарий",sendOrder:"Отправить заявку ↗",realIntegrationsNote:"Заявка сохранится локально в демо-версии. Для реальных заказов нужен сервер.",phoneInvalid:"Проверьте номер телефона.",orderSaved:"Заявка сохранена в этом браузере. Реальная отправка не подключена.",adminDemoHint:"Демо-доступ. Перед публикацией настройте серверную авторизацию.",adminPassword:"Пароль администратора",login:"Войти",adminWrong:"Неверный пароль.",adminOrders:"Последние заявки",adminAddProduct:"Добавить товар",productName:"Название",productPrice:"Цена (сум)",productCategory:"Категория",addProduct:"Добавить товар",logout:"Выйти из панели",productAdded:"Товар добавлен.",statusNew:"Новая",statusConfirmed:"Подтверждена",statusDelivery:"Доставка",statusDone:"Завершена",orderStatusUpdated:"Статус заказа обновлён.",products:"Товары",orders:"Заявки",orderValue:"Сумма заказов",noOrders:"Заявок пока нет.",loggedOut:"Вы вышли из панели.",newsletterSaved:"Спасибо! Заявка сохранена в браузере.",remove:"Удалить"
  },
  uz: {
    announcement:"5 000 000 so‘mdan bepul yetkazib berish · 14 kun ichida qaytarish",navCatalog:"Katalog",navCollections:"To‘plamlar",navAbout:"Brend haqida",navContacts:"Aloqa",searchPlaceholder:"Mebel qidirish...",
    heroEyebrow:"GO‘ZAL YASHASH SAN’ATI",heroTitleA:"O‘zingizga xos",heroTitleB:"qulay",heroTitleC:"makon yarating.",heroText:"Puxta o‘ylangan mebel, tabiiy teksturalar va uyingizni o‘zgacha maskanga aylantiruvchi detallar.",heroButton:"To‘plamni ko‘rish ↗",learnMore:"FURNIX haqida",heroNote:"O‘ziga xos dizayn. Har kunlik qulaylik.",trustOne:"O‘ylangan dizayn",trustTwo:"Sifatli materiallar",trustThree:"O‘zbekiston bo‘ylab yetkazish",trustFour:"Xariddan keyingi yordam",
    categoryEyebrow:"O‘Z USLUBINGIZNI TOPING",categoryTitle:"O‘ziga xos xonalar",allCategories:"Barcha toifalar ↗",catBeds:"Karavot va yotoqxonalar",catSofas:"Divanlar",catStorage:"Shkaf va komodlar",catTables:"Stol va stullar",catalogEyebrow:"FURNIX TANLOVI",catalogTitle:"Hayot uchun buyumlar",filterAll:"Barchasi",filterBeds:"Karavotlar",filterSofas:"Divanlar",filterStorage:"Shkaflar",filterTables:"Stollar",filterOther:"Boshqa",sortFeatured:"Mashhurlari avval",sortLow:"Arzonlari avval",sortHigh:"Qimmatlari avval",emptyProducts:"Hech narsa topilmadi.",addToCart:"Savatga qo‘shish",categoryBeds:"Yotoqxona",categorySofas:"Mehmonxona",categoryStorage:"Saqlash",categoryTables:"Oshxona",categoryOther:"Boshqa",added:"Savatga qo‘shildi",favoriteAdded:"Sevimlilarga qo‘shildi",favoriteRemoved:"Sevimlilardan olib tashlandi",
    editorialEyebrow:"KAMROQ, AMMO YAXSHIROQ",editorialTitle:"Go‘zallik —<br><em>soddalikda.</em>",editorialText:"Bizningcha, mebel shunchaki joyni to‘ldirmasligi, balki uyingizda o‘zingizni qulay his qilishingizga yordam berishi kerak.",editorialLink:"Katalogni ochish ↗",benefitsEyebrow:"NEGA FURNIX",benefitsTitle:"Ortiqcha tashvishlarsiz xarid",benefitOneTitle:"E’tibor bilan tanlash",benefitOneText:"Interyeringizga mos mebel tanlashga yordam beramiz.",benefitTwoTitle:"Yetkazish va yig‘ish",benefitTwoText:"Yetkazib berish vaqtini kelishib olamiz.",benefitThreeTitle:"Ishonchli materiallar",benefitThreeText:"Sifat va ijroga alohida e’tibor.",benefitFourTitle:"Doimiy yordam",benefitFourText:"Xariddan keyin ham aloqada qolamiz.",
    newsletterEyebrow:"FURNIX JURNALI",newsletterTitle:"Uyingiz uchun ilhom.",newsletterText:"Telefon raqamingizni qoldiring — bog‘lanamiz.",subscribe:"So‘rov yuborish ↗",privacyNote:"Demo forma: so‘rov faqat shu brauzerda saqlanadi.",footerText:"Yashashni istaydigan makon yaratamiz.",footerExplore:"Ko‘rib chiqing",footerContact:"Bog‘lanish",footerVisit:"Manzilimiz",addressText:"Toshkent, O‘zbekiston",openMap:"Xaritani ochish ↗",adminEntry:"Administrator kirishi",rights:"Barcha huquqlar himoyalangan.",footerMade:"Makon dizayni shu yerdan boshlanadi.",
    cartTitle:"Savatingiz",total:"Jami",checkout:"Buyurtma berish ↗",checkoutDemo:"Demo rejim: to‘lov va yuborish ulanmagan.",emptyCart:"Savatingiz hozircha bo‘sh.",checkoutTitle:"Buyurtmani rasmiylashtirish",yourName:"Ismingiz",phone:"Telefon raqami",deliveryAddress:"Yetkazib berish manzili",orderComment:"Izoh",sendOrder:"So‘rov yuborish ↗",realIntegrationsNote:"Demo versiyada so‘rov brauzerda saqlanadi. Haqiqiy buyurtmalar uchun server kerak.",phoneInvalid:"Telefon raqamini tekshiring.",orderSaved:"So‘rov shu brauzerda saqlandi. Haqiqiy yuborish ulanmagan.",adminDemoHint:"Demo kirish. Saytni e’lon qilishdan oldin server autentifikatsiyasini sozlang.",adminPassword:"Administrator paroli",login:"Kirish",adminWrong:"Parol noto‘g‘ri.",adminOrders:"So‘nggi buyurtmalar",adminAddProduct:"Mahsulot qo‘shish",productName:"Nomi",productPrice:"Narxi (so‘m)",productCategory:"Toifasi",addProduct:"Mahsulot qo‘shish",logout:"Paneldan chiqish",productAdded:"Mahsulot qo‘shildi.",statusNew:"Yangi",statusConfirmed:"Tasdiqlangan",statusDelivery:"Yetkazilmoqda",statusDone:"Yakunlangan",orderStatusUpdated:"Buyurtma holati yangilandi.",products:"Mahsulotlar",orders:"Buyurtmalar",orderValue:"Buyurtmalar summasi",noOrders:"Hozircha buyurtmalar yo‘q.",loggedOut:"Paneldan chiqdingiz.",newsletterSaved:"Rahmat! So‘rov brauzerda saqlandi.",remove:"O‘chirish"
  },
  en: {
    announcement:"Free delivery over UZS 5,000,000 · 14-day returns",navCatalog:"Catalog",navCollections:"Collections",navAbout:"About",navContacts:"Contact",searchPlaceholder:"Search furniture...",
    heroEyebrow:"THE ART OF BEAUTIFUL LIVING",heroTitleA:"A space",heroTitleB:"that feels",heroTitleC:"like home.",heroText:"Thoughtful furniture, natural textures and details that turn a house into a special place.",heroButton:"Explore collection ↗",learnMore:"Discover FURNIX",heroNote:"Distinctive design. Everyday comfort.",trustOne:"Thoughtful design",trustTwo:"Quality materials",trustThree:"Delivery across Uzbekistan",trustFour:"Care after purchase",
    categoryEyebrow:"FIND YOUR STYLE",categoryTitle:"Rooms with character",allCategories:"All categories ↗",catBeds:"Beds & bedrooms",catSofas:"Sofas & lounge",catStorage:"Wardrobes & dressers",catTables:"Tables & chairs",catalogEyebrow:"THE FURNIX EDIT",catalogTitle:"Objects for living",filterAll:"All",filterBeds:"Beds",filterSofas:"Sofas",filterStorage:"Storage",filterTables:"Tables",filterOther:"Other",sortFeatured:"Featured first",sortLow:"Price: low to high",sortHigh:"Price: high to low",emptyProducts:"No products found.",addToCart:"Add to cart",categoryBeds:"Bedroom",categorySofas:"Living",categoryStorage:"Storage",categoryTables:"Dining",categoryOther:"Other",added:"Added to cart",favoriteAdded:"Added to favorites",favoriteRemoved:"Removed from favorites",
    editorialEyebrow:"LESS, BUT BETTER",editorialTitle:"Beauty is —<br><em>in simplicity.</em>",editorialText:"We believe furniture should do more than fill a room. It should help you feel at home.",editorialLink:"Explore the catalog ↗",benefitsEyebrow:"WHY FURNIX",benefitsTitle:"A simpler way to shop",benefitOneTitle:"Thoughtful guidance",benefitOneText:"We help you find furniture for your interior.",benefitTwoTitle:"Delivery & assembly",benefitTwoText:"We arrange a convenient delivery time.",benefitThreeTitle:"Reliable materials",benefitThreeText:"Careful attention to quality and craft.",benefitFourTitle:"Here to help",benefitFourText:"We stay in touch after your purchase.",
    newsletterEyebrow:"FURNIX JOURNAL",newsletterTitle:"Inspiration for your home.",newsletterText:"Leave your number and we’ll contact you.",subscribe:"Request a call ↗",privacyNote:"Demo form: your request is saved only in this browser.",footerText:"Creating spaces where you love to be.",footerExplore:"Explore",footerContact:"Get in touch",footerVisit:"Find us",addressText:"Tashkent, Uzbekistan",openMap:"Open map ↗",adminEntry:"Administrator login",rights:"All rights reserved.",footerMade:"A better space starts here.",
    cartTitle:"Your cart",total:"Total",checkout:"Continue to checkout ↗",checkoutDemo:"Demo mode: payment and order submission are not connected.",emptyCart:"Your cart is empty.",checkoutTitle:"Checkout",yourName:"Your name",phone:"Phone number",deliveryAddress:"Delivery address",orderComment:"Comment",sendOrder:"Send request ↗",realIntegrationsNote:"In this demo, requests are stored in this browser. A server is required for real orders.",phoneInvalid:"Please check the phone number.",orderSaved:"Request saved in this browser. Live submission is not connected.",adminDemoHint:"Demo access. Configure server-side authentication before publishing.",adminPassword:"Administrator password",login:"Log in",adminWrong:"Incorrect password.",adminOrders:"Recent orders",adminAddProduct:"Add product",productName:"Name",productPrice:"Price (UZS)",productCategory:"Category",addProduct:"Add product",logout:"Log out",productAdded:"Product added.",statusNew:"New",statusConfirmed:"Confirmed",statusDelivery:"Delivery",statusDone:"Completed",orderStatusUpdated:"Order status updated.",products:"Products",orders:"Orders",orderValue:"Order value",noOrders:"No orders yet.",loggedOut:"You have logged out.",newsletterSaved:"Thank you! Your request was saved in this browser.",remove:"Remove"
  }
};

const seedProducts = [
  {id:1,name:{ru:"Кровать Noma",uz:"Noma karavoti",en:"Noma Bed"},category:"beds",price:6850000,image:"https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=850&q=85",tag:"Bestseller"},
  {id:2,name:{ru:"Диван Arco",uz:"Arco divani",en:"Arco Sofa"},category:"sofas",price:12400000,image:"https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=850&q=85",tag:"New"},
  {id:3,name:{ru:"Комод Linea",uz:"Linea komodi",en:"Linea Dresser"},category:"storage",price:4350000,image:"https://images.unsplash.com/photo-1595428774223-ef52624120d2?auto=format&fit=crop&w=850&q=85",tag:""},
  {id:4,name:{ru:"Стол Forma",uz:"Forma stoli",en:"Forma Table"},category:"tables",price:5200000,image:"https://images.unsplash.com/photo-1499933374294-4584851497cc?auto=format&fit=crop&w=850&q=85",tag:"Popular"},
  {id:5,name:{ru:"Кресло Miro",uz:"Miro kreslosi",en:"Miro Armchair"},category:"other",price:3850000,image:"https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?auto=format&fit=crop&w=850&q=85",tag:""},
  {id:6,name:{ru:"Кровать Alba",uz:"Alba karavoti",en:"Alba Bed"},category:"beds",price:7950000,image:"https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=850&q=85",tag:""},
  {id:7,name:{ru:"Диван Cloud",uz:"Cloud divani",en:"Cloud Sofa"},category:"sofas",price:10900000,image:"https://images.unsplash.com/photo-1550254478-ead40cc54513?auto=format&fit=crop&w=850&q=85",tag:""},
  {id:8,name:{ru:"Стол Oak",uz:"Oak stoli",en:"Oak Table"},category:"tables",price:6100000,image:"https://images.unsplash.com/photo-1449247709967-d4461a6a6103?auto=format&fit=crop&w=850&q=85",tag:""}
];

const readStore = (key, fallback) => {
  try { const value = JSON.parse(localStorage.getItem(key)); return value ?? fallback; }
  catch { return fallback; }
};
let products = readStore("furnix_products", seedProducts);
let cart = readStore("furnix_cart", []);
let orders = readStore("furnix_orders", []);
let leads = readStore("furnix_leads", []);
let favorites = readStore("furnix_favorites", []);
let currentLang = localStorage.getItem("furnix_lang") || "ru";
let currentFilter = "all";
let adminLoggedIn = false;

const t = key => translations[currentLang]?.[key] ?? translations.ru[key] ?? key;
const money = value => new Intl.NumberFormat(currentLang === "en" ? "en-US" : "ru-RU").format(Number(value) || 0) + (currentLang === "en" ? " UZS" : " сум");
const productName = product => typeof product.name === "object" ? (product.name[currentLang] || product.name.ru || product.name.en) : product.name;
const categoryName = category => t("category" + category[0].toUpperCase() + category.slice(1));
const save = () => {
  localStorage.setItem("furnix_products", JSON.stringify(products));
  localStorage.setItem("furnix_cart", JSON.stringify(cart));
  localStorage.setItem("furnix_orders", JSON.stringify(orders));
  localStorage.setItem("furnix_leads", JSON.stringify(leads));
  localStorage.setItem("furnix_favorites", JSON.stringify(favorites));
};
const escapeHTML = value => String(value ?? "").replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));
const toast = message => {
  const el = $("#toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.classList.remove("show"), 2600);
};
const validPhone = phone => /^\+?[\d\s()-]{9,18}$/.test(phone.trim()) && phone.replace(/\D/g,"").length >= 9;

function applyLanguage() {
  document.documentElement.lang = currentLang;
  $("#languageSelect").value = currentLang;
  $$("[data-i18n]").forEach(el => {
    const value = t(el.dataset.i18n);
    if (value.includes("<br>") || value.includes("<em>")) el.innerHTML = value;
    else el.textContent = value;
  });
  $$("[data-i18n-placeholder]").forEach(el => el.placeholder = t(el.dataset.i18nPlaceholder));
  localStorage.setItem("furnix_lang", currentLang);
  renderProducts();
  renderCart();
  if (adminLoggedIn) renderAdmin();
}

function renderProducts() {
  const query = ($("#searchInput").value || "").trim().toLowerCase();
  let list = products.filter(p => {
    const name = typeof p.name === "object" ? Object.values(p.name).join(" ") : p.name;
    return (currentFilter === "all" || p.category === currentFilter) && name.toLowerCase().includes(query);
  });
  const sort = $("#sortSelect").value;
  if (sort === "low") list.sort((a,b) => a.price-b.price);
  if (sort === "high") list.sort((a,b) => b.price-a.price);
  $("#productGrid").innerHTML = list.map((p,index) => `
    <article class="product-card" style="animation-delay:${index*45}ms">
      <div class="product-image-wrap">
        <img src="${escapeHTML(p.image)}" alt="${escapeHTML(productName(p))}" loading="lazy" onerror="this.src='https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=850&q=80'">
        ${p.tag ? `<span class="product-tag">${escapeHTML(p.tag)}</span>` : ""}
        <button class="favorite-btn ${favorites.includes(p.id)?"active":""}" data-favorite="${p.id}" aria-label="Favorite">♡</button>
        <button class="quick-add" data-add="${p.id}">${t("addToCart")}</button>
      </div>
      <div class="product-info"><div class="product-meta"><span>${escapeHTML(categoryName(p.category))}</span><span>FURNIX / ${String(p.id).padStart(3,"0")}</span></div><h3>${escapeHTML(productName(p))}</h3><div class="product-price">${money(p.price)}</div></div>
    </article>`).join("");
  $("#emptyState").classList.toggle("hidden", list.length !== 0);
}

function renderCart() {
  const count = cart.reduce((sum,item) => sum + item.qty, 0);
  $("#cartCount").textContent = count;
  const rows = cart.map(item => {
    const p = products.find(product => product.id === item.id);
    if (!p) return "";
    return `<div class="cart-item"><img src="${escapeHTML(p.image)}" alt=""><div><h4>${escapeHTML(productName(p))}</h4><p>${money(p.price)}</p><div class="qty-controls"><button data-qty="${p.id}" data-change="-1">−</button><span>${item.qty}</span><button data-qty="${p.id}" data-change="1">+</button></div></div><button class="remove-item" data-remove="${p.id}" aria-label="${t("remove")}">×</button></div>`;
  }).join("");
  $("#cartItems").innerHTML = rows || `<p class="muted">${t("emptyCart")}</p>`;
  const total = cart.reduce((sum,item) => sum + (products.find(p => p.id === item.id)?.price || 0) * item.qty,0);
  $("#cartTotal").textContent = money(total);
  $("#checkoutOpen").disabled = !cart.length;
  $("#checkoutOpen").style.opacity = cart.length ? "1" : ".45";
  $("#checkoutSummary").textContent = cart.map(item => {
    const p = products.find(product => product.id === item.id);
    return p ? `${productName(p)} × ${item.qty}` : "";
  }).filter(Boolean).join(" · ") + ` — ${money(total)}`;
  save();
}

function openCart() {
  $("#overlay").classList.add("active");
  $("#cartDrawer").classList.add("open");
}
function closeCart() {
  $("#overlay").classList.remove("active");
  $("#cartDrawer").classList.remove("open");
}
function openModal(id) { $("#" + id).classList.add("open"); document.body.style.overflow = "hidden"; }
function closeModal(id) { $("#" + id).classList.remove("open"); document.body.style.overflow = ""; }

$("#languageSelect").addEventListener("change", e => { currentLang = e.target.value; applyLanguage(); });
$("#themeToggle").addEventListener("click", () => {
  document.body.classList.toggle("dark");
  const dark = document.body.classList.contains("dark");
  localStorage.setItem("furnix_theme", dark ? "dark" : "light");
  $("#themeToggle").textContent = dark ? "☀" : "☾";
});
if (localStorage.getItem("furnix_theme") === "dark") { document.body.classList.add("dark"); $("#themeToggle").textContent = "☀"; }

$("#searchInput").addEventListener("input", renderProducts);
$("#sortSelect").addEventListener("change", renderProducts);
$("#filterPills").addEventListener("click", e => {
  const button = e.target.closest("[data-filter]");
  if (!button) return;
  currentFilter = button.dataset.filter;
  $$(".filter-pill").forEach(p => p.classList.toggle("active", p === button));
  renderProducts();
});
$$(".category-card").forEach(card => card.addEventListener("click", () => {
  currentFilter = card.dataset.category;
  $$(".filter-pill").forEach(p => p.classList.toggle("active", p.dataset.filter === currentFilter));
  renderProducts();
  $("#catalog").scrollIntoView({behavior:"smooth"});
}));
$("#productGrid").addEventListener("click", e => {
  const add = e.target.closest("[data-add]");
  const favorite = e.target.closest("[data-favorite]");
  if (add) {
    const id = Number(add.dataset.add);
    const existing = cart.find(item => item.id === id);
    existing ? existing.qty++ : cart.push({id,qty:1});
    renderCart(); toast(t("added"));
  }
  if (favorite) {
    const id = Number(favorite.dataset.favorite);
    favorites = favorites.includes(id) ? favorites.filter(x => x !== id) : [...favorites,id];
    save(); renderProducts(); toast(t(favorites.includes(id) ? "favoriteAdded" : "favoriteRemoved"));
  }
});
$("#cartOpen").addEventListener("click", openCart);
$("#cartClose").addEventListener("click", closeCart);
$("#overlay").addEventListener("click", closeCart);
$("#cartItems").addEventListener("click", e => {
  const qty = e.target.closest("[data-qty]");
  const remove = e.target.closest("[data-remove]");
  if (qty) {
    const item = cart.find(x => x.id === Number(qty.dataset.qty));
    if (item) item.qty += Number(qty.dataset.change);
    cart = cart.filter(x => x.qty > 0);
    renderCart();
  }
  if (remove) { cart = cart.filter(x => x.id !== Number(remove.dataset.remove)); renderCart(); }
});
$("#prevProducts").addEventListener("click", () => $("#productGrid").scrollBy({left:-$("#productGrid").clientWidth*.8,behavior:"smooth"}));
$("#nextProducts").addEventListener("click", () => $("#productGrid").scrollBy({left:$("#productGrid").clientWidth*.8,behavior:"smooth"}));

$("#checkoutOpen").addEventListener("click", () => {
  if (!cart.length) return;
  closeCart(); openModal("checkoutModal");
});
$$("[data-close]").forEach(button => button.addEventListener("click", () => closeModal(button.dataset.close)));
$$(".modal").forEach(modal => modal.addEventListener("click", e => { if (e.target === modal) closeModal(modal.id); }));
document.addEventListener("keydown", e => {
  if (e.key === "Escape") { closeCart(); $$(".modal.open").forEach(m => closeModal(m.id)); }
});

$("#checkoutForm").addEventListener("submit", e => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target));
  if (!validPhone(data.phone)) { toast(t("phoneInvalid")); return; }
  const items = cart.map(item => {
    const p = products.find(x => x.id === item.id);
    return p ? {id:p.id,name:productName(p),price:p.price,qty:item.qty} : null;
  }).filter(Boolean);
  const total = items.reduce((sum,item) => sum + item.price*item.qty,0);
  orders.unshift({id:Date.now(),...data,items,total,status:"new",date:new Date().toLocaleString()});
  cart = []; save(); renderCart(); e.target.reset(); closeModal("checkoutModal");
  toast(t("orderSaved"));
  if (adminLoggedIn) renderAdmin();
});
$("#newsletterForm").addEventListener("submit", e => {
  e.preventDefault();
  const phone = $("#newsletterPhone").value;
  if (!validPhone(phone)) { toast(t("phoneInvalid")); return; }
  leads.unshift({phone,date:new Date().toLocaleString()}); save(); e.target.reset(); toast(t("newsletterSaved"));
});

$("#adminOpen").addEventListener("click", () => openModal("adminModal"));
$("#adminLogin").addEventListener("click", () => {
  if ($("#adminPassword").value !== "furnix2026") { toast(t("adminWrong")); return; }
  adminLoggedIn = true;
  $("#adminLoginView").classList.add("hidden");
  $("#adminPanelView").classList.remove("hidden");
  renderAdmin();
});
function renderAdmin() {
  $("#adminStats").innerHTML = `<div class="stat"><b>${products.length}</b><span>${t("products")}</span></div><div class="stat"><b>${orders.length}</b><span>${t("orders")}</span></div><div class="stat"><b>${money(orders.reduce((s,o)=>s+o.total,0))}</b><span>${t("orderValue")}</span></div>`;
  $("#adminOrdersList").innerHTML = orders.length ? orders.slice(0,15).map(order => `
    <div class="admin-order"><strong>#${order.id} · ${escapeHTML(order.name)} · ${money(order.total)}</strong><br>${escapeHTML(order.phone)} · ${escapeHTML(order.address)}<br>${(order.items||[]).map(i=>`${escapeHTML(i.name)} × ${i.qty}`).join(", ")}<br>
    <select data-status="${order.id}"><option value="new" ${order.status==="new"?"selected":""}>${t("statusNew")}</option><option value="confirmed" ${order.status==="confirmed"?"selected":""}>${t("statusConfirmed")}</option><option value="delivery" ${order.status==="delivery"?"selected":""}>${t("statusDelivery")}</option><option value="done" ${order.status==="done"?"selected":""}>${t("statusDone")}</option></select></div>`).join("") : `<p class="muted">${t("noOrders")}</p>`;
}
$("#adminOrdersList").addEventListener("change", e => {
  const id = Number(e.target.dataset.status);
  const order = orders.find(o => o.id === id);
  if (order) { order.status = e.target.value; save(); toast(t("orderStatusUpdated")); }
});
$("#addProductForm").addEventListener("submit", e => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target));
  const name = data.name.trim();
  const price = Number(data.price);
  if (!name || !Number.isFinite(price) || price <= 0) return;
  products.unshift({id:Date.now(),name:{ru:name,uz:name,en:name},category:data.category,price,image:data.image || "https://images.unsplash.com/photo-1499933374294-4584851497cc?auto=format&fit=crop&w=850&q=85",tag:"New"});
  save(); renderProducts(); renderAdmin(); e.target.reset(); toast(t("productAdded"));
});
$("#adminLogout").addEventListener("click", () => {
  adminLoggedIn = false; $("#adminPanelView").classList.add("hidden"); $("#adminLoginView").classList.remove("hidden"); $("#adminPassword").value = ""; closeModal("adminModal"); toast(t("loggedOut"));
});
$("#menuToggle").addEventListener("click", () => $("#desktopNav").classList.toggle("mobile-open"));
$$(".desktop-nav a").forEach(link => link.addEventListener("click", () => $("#desktopNav").classList.remove("mobile-open")));

applyLanguage();
renderProducts();
renderCart();
